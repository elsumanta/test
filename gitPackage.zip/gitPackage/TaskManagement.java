package gitPackage;

import java.io.IOException;
import java.util.concurrent.ScheduledExecutorService;


public class TaskManagement implements Runnable {
        private FollowupTask followup;
        private ScheduledExecutorService executorService;

        public TaskManagement(FollowupTask followup, ScheduledExecutorService executorService) {
            this.followup = followup;
            this.executorService = executorService;
        }

        @Override
        public void run() {
            GitController gitDelivery = new GitController();
            ConfigurationFile cf = ConfigurationFile.getInstance();
            
            gitDelivery.setCredential(cf.userName, cf.password);
            gitDelivery.setGitDirectory(cf.deliveryPath);
            try {
				gitDelivery.init();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
            
            do {
            	//wn.displayTray("Delivery Sage", "Start Checking");
            	sleep(cf.timoutChecker);
			} while (!gitDelivery.sendPullRequest() && cf.whileChecker);
                        
            //Triger Popup Windows
            executorService.submit(followup);
        }



    static void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            throw new IllegalStateException("I shouldn't be interrupted!", e);
        }
    }
}
