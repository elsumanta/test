package gitPackage;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;

public class WindowsNotification {
	private static WindowsNotification WNObject = null;
	
	private WindowsNotification() {
	}
	
	public static WindowsNotification getInstance() {

		if(WNObject == null) {
			WNObject = new WindowsNotification();
		}
		return WNObject;
	}
	
	public boolean isSupported() {
		return SystemTray.isSupported();

	}
	
	 public void displayTray(String pHeader, String pMessage) {
			SystemTray tray =  SystemTray.getSystemTray();
			
			Image image =  Toolkit.getDefaultToolkit().createImage("icon.png");
			
			TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
			
			trayIcon.setImageAutoSize(true);
			trayIcon.setToolTip("System tray icon demo");
			try {
				tray.add(trayIcon);
			} catch (AWTException e) {
				e.printStackTrace();
			}
			trayIcon.displayMessage(pHeader, pMessage, MessageType.INFO);
	}
}
