package gitPackage;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import org.eclipse.jgit.api.AddCommand;
import org.eclipse.jgit.api.CommitCommand;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.PullCommand;
import org.eclipse.jgit.api.PullResult;
import org.eclipse.jgit.api.PushCommand;
import org.eclipse.jgit.api.errors.*;
import org.eclipse.jgit.internal.storage.file.FileRepository;
import org.eclipse.jgit.transport.CredentialsProvider;
import org.eclipse.jgit.transport.FetchResult;
import org.eclipse.jgit.transport.PushResult;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

public class GitController {
	/*private String name = "elim.poltek@gmail.com";
	private String password = "S4r4g1h1.";
	private String url = "https://github.com/elsumanta/test.git";
	private String localPath = "E:\\Software\\Git1\\.git";*/
	
	private Git mGit = null;
	private CredentialsProvider cp = null;
	private File gitDir = null;
	public static String gitMessage;

	/*public static void main(String[] args) {
		GitController a = new GitController();
		a.setCredential(a.name, a.password);
		a.setGitDirectory(a.localPath);
		try {
			a.init();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//a.sendPullRequest();
		try {
			System.out.println("cdadag");
			a.sendPushRequest();
		} catch (GitAPIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	
	public void setCredential(String userName, String password) {
		cp = new UsernamePasswordCredentialsProvider(userName, password);
	}
	
	public void setGitDirectory(String localPath) {
		gitDir = new File(localPath);
	}
	
	public void init() throws IOException {
		FileRepository repo = new FileRepository(gitDir);
		if (mGit == null) {
			mGit = new Git(repo);
		}	
	}
    
	public boolean sendPullRequest() {
		boolean status = false; 
		try {
			PullCommand puller = mGit.pull();
			puller.setCredentialsProvider(cp);
			puller.setTimeout(60);
			PullResult pullResult = puller.call();
			if (pullResult != null) {
				FetchResult result = pullResult.getFetchResult();
				if (result.getTrackingRefUpdates().isEmpty()) {
					System.out.println("g ada update");
					gitMessage = "g ada update";
					status = false;
				} else {
					System.out.println("Udah pull");
					gitMessage = "New Data";
					status =  true;
				}
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
		return status;
	}
	
	@SuppressWarnings("unused")
	private void sendPushRequest() throws TransportException, GitAPIException {
		// add
        AddCommand ac = mGit.add();
        ac.addFilepattern(".");
        try {
            ac.call();
        } catch (NoFilepatternException e) {
            e.printStackTrace();
        }

        // commit
        CommitCommand commit = mGit.commit();
        commit.setMessage("Send Request");
        try {
            commit.call();
        } catch (NoHeadException e) {
            e.printStackTrace();
        } catch (NoMessageException e) {
            e.printStackTrace();
        } catch (ConcurrentRefUpdateException e) {
            e.printStackTrace();
        } catch (WrongRepositoryStateException e) {
            e.printStackTrace();
        }
        // push
        PushCommand pc = mGit.push();
        pc.setCredentialsProvider(cp)
                .setForce(true)
                .setPushAll();
        try {
            Iterator<PushResult> it = pc.call().iterator();
            if(it.hasNext()){
                System.out.println(it.next().toString());
            }
        } catch (InvalidRemoteException e) {
            e.printStackTrace();
        }

	}
}
