package gitPackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigurationFile {
	
	private static ConfigurationFile cfInstance = null;
	public String userName;
	public String password;
	public String deliveryURL;
	public String requestURL;
	public String deliveryPath;
	public String reuqestPath;
	public Long timoutChecker;
	public boolean whileChecker;
	
	private ConfigurationFile() {
		// TODO Auto-generated constructor stub
	}
		
	public static ConfigurationFile getInstance() {
		if(cfInstance == null){
			cfInstance = new ConfigurationFile();
			cfInstance.loadConfiguration();
		}
		
		return cfInstance;
	}
	
	private void loadConfiguration() {
		Properties prop = new Properties();
		InputStream input = null;
		
		try {
			input = new FileInputStream("config.properties");
			prop.load(input);
			
			userName = prop.getProperty("UsernamName");
			password = prop.getProperty("Password");
			requestURL = prop.getProperty("RequestURL");
			deliveryURL = prop.getProperty("DeliveryURL");
			reuqestPath = prop.getProperty("RequestPath");
			deliveryPath = prop.getProperty("DeliveryPath");
			timoutChecker = Long.parseLong(prop.getProperty("timoutChecker"));
			whileChecker = Boolean.valueOf(prop.getProperty("whileChecker"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (input != null ){
				try {
					input.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
