package gitPackage;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.swing.JButton;
public class FollowupTask implements Runnable {
        private int invocationCount = 0;
        private ScheduledExecutorService executorService;
        private JButton eventButton = null;

        public FollowupTask(ScheduledExecutorService executorService, JButton pEventButton) {
            this.executorService = executorService;
            eventButton = pEventButton;
        }

        @Override
        public void run() {
            invocationCount++;
            /*
            if (invocationCount == 1) {
                System.out.println("Followup task: resubmit while invocationCount < 20");
            }
            System.out.println("invocationCount = " + invocationCount);
            */
            
            if (invocationCount < 1) {
                executorService.schedule(this, 250, TimeUnit.MILLISECONDS);
            } else {
            	WindowsNotification wn = WindowsNotification.getInstance();
            	if(wn.isSupported()) {
            		wn.displayTray("Delivery Sage", GitController.gitMessage);
            		if(eventButton != null) {
                		eventButton.setEnabled(true);
            		}
            	}
                executorService.shutdown();
            }
        }
        
    }
