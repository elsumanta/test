package guiPackage;

import java.awt.EventQueue;

import javax.swing.JFrame;

import gitPackage.FollowupTask;
import gitPackage.TaskManagement;

import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.awt.GridLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class MainConsole {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainConsole window = new MainConsole();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainConsole() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnCheckingSageDelivery = new JButton("Checking Sage Delivery");
		btnCheckingSageDelivery.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				btnCheckingSageDelivery.setEnabled(false);
				//Thread Pooling
		        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
		        
		        //Preparing Task
		        FollowupTask followupTask = new FollowupTask(executorService, btnCheckingSageDelivery);
		        TaskManagement firstTask = new TaskManagement(followupTask, executorService);
		        
		        //Execute Task
		        executorService.submit(firstTask);
			}
		});
		
		JButton btnSendRequest = new JButton("Send Request");
		btnSendRequest.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnCheckingSageDelivery.setEnabled(false);
				btnSendRequest.setEnabled(false);
			}
		});
		
		JButton btnConfiguration = new JButton("Settings");
		btnConfiguration.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainConsole mainWindows = new MainConsole();
				JavaEditor settings = new JavaEditor();
		
				//mainWindows.frame.setVisible(false);
				mainWindows.frame.dispose();
				settings.setOldFrame(mainWindows.frame);
				settings.frame.setVisible(true);
			}
		});
		
		JLabel lblSageRequestMonitoring = new JLabel("Sage Monitoring Request");
		lblSageRequestMonitoring.setFont(new Font("Tahoma", Font.PLAIN, 33));
		
		GroupLayout groupLayout = new GroupLayout(frame.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(26)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnConfiguration, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 379, Short.MAX_VALUE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(btnCheckingSageDelivery, GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
							.addGap(6)
							.addComponent(btnSendRequest, GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE)))
					.addGap(29))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(36)
					.addComponent(lblSageRequestMonitoring)
					.addContainerGap(38, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(25)
					.addComponent(lblSageRequestMonitoring)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCheckingSageDelivery, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnSendRequest, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnConfiguration, GroupLayout.PREFERRED_SIZE, 42, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(79, Short.MAX_VALUE))
		);
		frame.getContentPane().setLayout(groupLayout);
	}
}
