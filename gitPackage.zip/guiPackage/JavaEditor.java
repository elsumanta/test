package guiPackage;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JEditorPane;
import java.awt.BorderLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JFileChooser;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class JavaEditor {

	public JFrame frame;
	private JFrame oldFrame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JavaEditor window = new JavaEditor();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public JavaEditor() {
		initialize();
	}

	public void setOldFrame(JFrame oldFrame) {
		this.oldFrame = oldFrame;
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);
		
		JButton btnSave = new JButton("Save");
		JButton btnLoad = new JButton("Load");
		JTextArea textArea = new JTextArea();
		
		springLayout.putConstraint(SpringLayout.WEST, btnSave, 10, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, btnSave, -10, SpringLayout.SOUTH, frame.getContentPane());
		frame.getContentPane().add(btnSave);
		
		springLayout.putConstraint(SpringLayout.NORTH, textArea, 0, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, textArea, 10, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, textArea, -6, SpringLayout.NORTH, btnSave);
		springLayout.putConstraint(SpringLayout.EAST, textArea, 424, SpringLayout.WEST, frame.getContentPane());
		frame.getContentPane().add(textArea);
		

		springLayout.putConstraint(SpringLayout.NORTH, btnLoad, 0, SpringLayout.NORTH, btnSave);
		springLayout.putConstraint(SpringLayout.WEST, btnLoad, 6, SpringLayout.EAST, btnSave);
		frame.getContentPane().add(btnLoad);
		
		JButton btnBack = new JButton("Back");
		btnBack.setEnabled(false);
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JavaEditor settings = new JavaEditor();
				settings.frame.setVisible(false);
				
				oldFrame.setVisible(true);
			}
		});
		springLayout.putConstraint(SpringLayout.NORTH, btnBack, 0, SpringLayout.NORTH, btnSave);
		springLayout.putConstraint(SpringLayout.EAST, btnBack, -10, SpringLayout.EAST, frame.getContentPane());
		frame.getContentPane().add(btnBack);
		
		btnSave.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String str = "SomeMoreTextIsHere";
	            File newTextFile = new File("config.properties");

	            FileWriter fw;
				try {
					fw = new FileWriter(newTextFile);
					
		            fw.write(textArea.getText());
		            fw.close();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		
		btnLoad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String newLine = ""; 
				String oldLine = "";

				FileReader fr = null;
				try {
					fr = new FileReader("config.properties");
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} 
				BufferedReader in = new BufferedReader(fr); 
				try {
					while ((newLine = in.readLine()) != null) { 
						oldLine = oldLine + newLine + "\n"; 
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				} 
				textArea.setText(oldLine);
			}
		});
	}
}
